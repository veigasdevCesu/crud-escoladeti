import { PartialType } from '@nestjs/mapped-types';
import { CreateVeiculoDto } from './create-veiculo.dto';

new class UpdateVeiculoDto {

    modelo: String;

    anoFabricacao: Number;

    placa: String;

}

export class UpdateVeiculoDto extends PartialType(CreateVeiculoDto) {}
