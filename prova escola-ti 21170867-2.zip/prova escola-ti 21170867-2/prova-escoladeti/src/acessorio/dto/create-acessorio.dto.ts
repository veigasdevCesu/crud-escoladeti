export class CreateAcessorioDto {

    nome: String;

}
