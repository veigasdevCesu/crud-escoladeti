import { PartialType } from '@nestjs/mapped-types';
import { CreateAcessorioDto } from './create-acessorio.dto';

new class UpdateAcessorioDto {

    nome: String;

}

export class UpdateAcessorioDto extends PartialType(CreateAcessorioDto) {}