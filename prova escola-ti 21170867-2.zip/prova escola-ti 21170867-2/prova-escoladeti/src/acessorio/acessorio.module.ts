import { Module } from '@nestjs/common';
import { AcessorioService } from './acessorio.service';
import { AcessorioController } from './acessorio.controller';

@Module({
  controllers: [AcessorioController],
  providers: [AcessorioService],
})
export class AcessorioModule {}
